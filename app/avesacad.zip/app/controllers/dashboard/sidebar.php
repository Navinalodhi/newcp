<?php
$type = $_SESSION['aves_type'];