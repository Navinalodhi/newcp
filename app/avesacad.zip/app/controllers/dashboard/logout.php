<?php

session_destroy();
redirectRoute('dashboard/login');