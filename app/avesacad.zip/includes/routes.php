<?php
/**
 * Created by PhpStorm.
 * User: anands
 * Date: 17/07/16
 * Time: 12:54 PM
 */


$_routes = [
	
    
    'welcome/{param}' => 'index'

];